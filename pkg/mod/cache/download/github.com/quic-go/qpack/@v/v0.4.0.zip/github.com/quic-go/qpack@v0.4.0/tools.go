//go:build tools

package qpack

import _ "github.com/onsi/ginkgo/v2/ginkgo"
