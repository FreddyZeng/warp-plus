// Package ffdata provides data-related helpers for ff packages.
package ffdata
