// Package fftest provides tools for testing flag sets.
package fftest
