// Package ffhelp provides tools to produce help text for flags and commands.
package ffhelp
