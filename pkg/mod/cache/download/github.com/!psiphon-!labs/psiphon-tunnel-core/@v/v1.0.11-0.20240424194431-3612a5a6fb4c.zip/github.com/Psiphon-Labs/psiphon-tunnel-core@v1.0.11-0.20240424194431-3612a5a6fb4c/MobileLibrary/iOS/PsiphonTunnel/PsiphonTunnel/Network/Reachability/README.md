# Reachability

This code is from: 

https://developer.apple.com/library/content/samplecode/Reachability/Introduction/Intro.html
