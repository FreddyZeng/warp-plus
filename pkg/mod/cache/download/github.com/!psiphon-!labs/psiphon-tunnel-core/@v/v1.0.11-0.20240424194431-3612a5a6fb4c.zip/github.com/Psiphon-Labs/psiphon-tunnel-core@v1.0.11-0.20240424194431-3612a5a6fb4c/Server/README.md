## Psiphon Tunnel Core Server README

### Build
Prerequisites:
 - Go 1.15 or later

Build Steps:
 - Build: `go build -o psiphond main.go`
