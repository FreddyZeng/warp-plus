2023-12-09

I hereby agree to the terms of the "Psiphon Individual Contributor License Agreement", with sha256 checksum 5c61081564a8afbe1bb91b48c291f93a9ead7ae92b5329d05a19bcc5ccec4b4b.

I furthermore declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Lanius Collaris https://github.com/Lanius-collaris
