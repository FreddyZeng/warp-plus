package handshake

//go:generate sh -c "../mockgen_internal.sh handshake mock_mint_tls_test.go github.com/Psiphon-Labs/psiphon-tunnel-core/psiphon/common/quic/gquic-go/internal/handshake mintTLS"
