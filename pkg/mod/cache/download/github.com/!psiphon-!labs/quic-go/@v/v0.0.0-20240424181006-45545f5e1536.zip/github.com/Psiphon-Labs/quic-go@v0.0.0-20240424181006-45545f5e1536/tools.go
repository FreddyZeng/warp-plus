//go:build tools
// +build tools

package quic

// [Psiphon]
// Avoid vendoring testing dependencies
//
//	_ "github.com/onsi/ginkgo/v2/ginkgo"
//	_ "go.uber.org/mock/mockgen"
